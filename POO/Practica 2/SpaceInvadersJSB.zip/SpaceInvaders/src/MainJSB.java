/**
 * 
 */

/**
 * @author jorgebonillo
 *
 */
public class MainJSB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JuegoSpace juego = new JuegoSpace();
		juego.game();
	}

}
